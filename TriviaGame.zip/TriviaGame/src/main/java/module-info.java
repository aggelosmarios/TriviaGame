module gr.unipi.TriviaGame {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
    requires trivia.api;
    requires java.net.http;

    exports gr.unipi.TriviaGame;
}

